'use client';

import { useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';

export default function ForgotPasswordPage() {
  const supabase = createClient();
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin;
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${siteUrl}/reset-password`,
    });

    setLoading(false);

    // Always show the same success state whether or not the email exists —
    // this prevents attackers from using this form to discover which
    // emails are registered.
    if (resetError && !resetError.message.toLowerCase().includes('rate limit')) {
      setError('Something went wrong. Please try again in a moment.');
      return;
    }
    if (resetError) {
      setError('Too many requests. Please wait a few minutes and try again.');
      return;
    }
    setSent(true);
  }

  if (sent) {
    return (
      <div className="auth-page">
        <div className="auth-card">
          <h1>Check your inbox</h1>
          <p className="sub">
            If an account exists for <strong>{email}</strong>, a password reset link is on its way.
          </p>
          <Link href="/login" className="btn btn-solid btn-block">Back to Login</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Reset your password</h1>
        <p className="sub">Enter your registered email and we&apos;ll send you a reset link.</p>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <button type="submit" className="btn btn-solid btn-block" disabled={loading}>
            {loading ? 'Sending…' : 'Send Reset Link'}
          </button>
        </form>

        <p className="auth-foot">
          Remembered it? <Link href="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}
