import { NextResponse } from 'next/server';
import { createClient as createSupabaseJsClient } from '@supabase/supabase-js';
import { createAdminClient } from '@/lib/supabase/server';

export async function POST(request: Request) {
  const authHeader = request.headers.get('Authorization');
  const token = authHeader?.replace('Bearer ', '');

  if (!token) {
    return NextResponse.json({ error: 'Not authenticated.' }, { status: 401 });
  }

  // Verify the token belongs to a real, currently-valid session using the
  // anon client — this is what stops any caller from deleting an arbitrary
  // user id. The service role key is only used afterwards, server-side.
  const verifyClient = createSupabaseJsClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
  const {
    data: { user },
    error: verifyError,
  } = await verifyClient.auth.getUser(token);

  if (verifyError || !user) {
    return NextResponse.json({ error: 'Invalid or expired session.' }, { status: 401 });
  }

  const admin = createAdminClient();
  const { error: deleteError } = await admin.auth.admin.deleteUser(user.id);

  if (deleteError) {
    return NextResponse.json({ error: 'Could not delete account.' }, { status: 500 });
  }

  // The profiles row is removed automatically via
  // "on delete cascade" on profiles.auth_user_id -> auth.users.id.
  return NextResponse.json({ success: true });
}
