import Link from 'next/link';

export default function HomePage() {
  return (
    <>
      <div className="hero-section" style={{ background: 'var(--navy)', color: '#fff', padding: '90px 0 50px' }}>
        <div className="wrap" style={{ textAlign: 'center', maxWidth: 760, margin: '0 auto' }}>
          <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, letterSpacing: '.14em', textTransform: 'uppercase', color: 'var(--emerald)' }}>
            Pharma · AI · Healthcare Careers
          </p>
          <h1 style={{ color: '#fff', fontSize: 'clamp(2.2rem, 5.6vw, 3.6rem)', lineHeight: 1.08, marginTop: 20 }}>
            Advancing Pharma<br />Through <span style={{ color: 'var(--emerald)' }}>AI</span>
          </h1>
          <p style={{ marginTop: 22, color: '#C7D4DC', fontSize: 16.5, maxWidth: '56ch', marginLeft: 'auto', marginRight: 'auto' }}>
            A knowledge hub for pharmacy and healthcare professionals — practical PV and analytics
            know-how, real interview prep, and where AI is genuinely changing drug safety work.
          </p>
          <div style={{ display: 'flex', gap: 14, justifyContent: 'center', marginTop: 34, flexWrap: 'wrap' }}>
            <Link href="/signup" className="btn btn-solid">Create Free Account</Link>
            <Link href="#resources" className="btn btn-dark-outline">Explore Resources</Link>
          </div>
        </div>
      </div>

      <div className="wrap app-shell">
        <section id="pv" style={{ marginBottom: 60 }}>
          <div style={{ maxWidth: 640, margin: '0 auto 40px', textAlign: 'center' }}>
            <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, color: 'var(--emerald)', letterSpacing: '.1em', textTransform: 'uppercase' }}>What we cover</p>
            <h2 style={{ marginTop: 10 }}>Four working areas, one practice</h2>
          </div>
          <div className="dash-grid">
            <div className="dash-card">
              <h3>Pharmacovigilance</h3>
              <p>Case intake, MedDRA coding, safety database entry, signal detection, and aggregate reporting.</p>
            </div>
            <div className="dash-card" id="analytics">
              <h3>Healthcare Analytics</h3>
              <p>Excel, SQL and Power BI dashboards built the way a pharma or hospital ops team actually uses them.</p>
            </div>
            <div className="dash-card" id="ai">
              <h3>AI in Pharma</h3>
              <p>Generative AI, prompt engineering, and AI-assisted drug safety — grounded, not hyped.</p>
            </div>
          </div>
        </section>

        <section id="career" style={{ marginBottom: 60 }}>
          <div className="panel">
            <h2>Career Hub</h2>
            <p style={{ color: 'var(--ink-soft)' }}>
              Resume guidance, interview prep, certifications, and project ideas for pharmacy and
              healthcare graduates moving into safety, analytics, or AI roles.
            </p>
          </div>
        </section>

        <section id="resources" style={{ marginBottom: 60 }}>
          <div style={{ maxWidth: 640, margin: '0 auto 40px', textAlign: 'center' }}>
            <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 11.5, color: 'var(--emerald)', letterSpacing: '.1em', textTransform: 'uppercase' }}>Start here</p>
            <h2 style={{ marginTop: 10 }}>Featured resources</h2>
          </div>
          <div className="dash-grid">
            <div className="dash-card">
              <h3>PV Interview E-Notes</h3>
              <p>Questions and answers written for pharmacovigilance freshers.</p>
              <Link href="/signup">Sign in to view →</Link>
            </div>
            <div className="dash-card">
              <h3>Healthcare Analytics Projects</h3>
              <p>Portfolio-ready projects in Excel, SQL, and Power BI.</p>
              <Link href="/signup">Sign in to view →</Link>
            </div>
            <div className="dash-card">
              <h3>Pharma Career Guide 2026</h3>
              <p>Career pathways after B.Pharm and MBA.</p>
              <Link href="/signup">Sign in to view →</Link>
            </div>
          </div>
        </section>

        <section id="about">
          <div className="panel" style={{ display: 'flex', gap: 32, alignItems: 'center', flexWrap: 'wrap' }}>
            <div className="avatar-lg">MP</div>
            <div>
              <h3 style={{ fontSize: '1.4rem' }}>Mayur Patil</h3>
              <p style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 13, color: 'var(--emerald)', margin: '8px 0 14px' }}>
                B.Pharm · MBA Business Analytics
              </p>
              <p style={{ color: 'var(--ink-soft)', maxWidth: '60ch' }}>
                Pharma AI is a knowledge platform focused on pharmacovigilance, healthcare analytics,
                digital health, and career development for pharmacy and healthcare professionals.
              </p>
            </div>
          </div>
        </section>
      </div>

      <footer className="site-footer">
        <div className="wrap foot-grid">
          <div>PHARMA<span style={{ color: 'var(--emerald)' }}>AI</span> — Advancing Pharma Through AI</div>
          <div>© 2026 Pharma AI</div>
        </div>
      </footer>
    </>
  );
}
