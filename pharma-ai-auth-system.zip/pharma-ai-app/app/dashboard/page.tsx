'use client';

import Link from 'next/link';
import { useAuth } from '@/components/AuthProvider';

export default function DashboardPage() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return <div className="centered-msg">Loading your dashboard…</div>;
  }

  const displayName = profile?.full_name || user?.email?.split('@')[0] || 'there';

  const fields = [profile?.full_name, profile?.avatar_url, profile?.bio, profile?.user_type];
  const completion = Math.round((fields.filter(Boolean).length / fields.length) * 100);

  return (
    <div className="wrap app-shell">
      <div className="app-header">
        <h1>Welcome to Pharma AI, {displayName}</h1>
        <p>Here&apos;s where you left off.</p>
      </div>

      <div className="stat-row">
        <div className="stat-card">
          <div className="num">0</div>
          <div className="label">RESOURCES ACCESSED</div>
        </div>
        <div className="stat-card">
          <div className="num">0</div>
          <div className="label">COURSES STARTED</div>
        </div>
        <div className="stat-card">
          <div className="num">0</div>
          <div className="label">SAVED RESOURCES</div>
        </div>
        <div className="stat-card">
          <div className="num">{completion}%</div>
          <div className="label">PROFILE COMPLETION</div>
        </div>
      </div>

      <div className="dash-grid">
        <div className="dash-card">
          <h3>My Profile</h3>
          <p>Update your name, avatar, user type, and bio.</p>
          <Link href="/profile">Open Profile →</Link>
        </div>
        <div className="dash-card">
          <h3>My Resources</h3>
          <p>Everything you&apos;ve unlocked so far, in one place.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>My Courses</h3>
          <p>Track progress across any course you&apos;ve started.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>Saved Resources</h3>
          <p>Bookmarked notes, guides, and projects.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>PV Interview E-Notes</h3>
          <p>Pharmacovigilance interview questions and answers.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>Healthcare Analytics Projects</h3>
          <p>Portfolio-ready Excel, SQL, and Power BI projects.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>Career Resources</h3>
          <p>Resume templates, interview prep, and certification guides.</p>
          <Link href="/dashboard">Coming soon →</Link>
        </div>
        <div className="dash-card">
          <h3>Recently Viewed</h3>
          <p>Nothing viewed yet — browse a resource to see it here.</p>
        </div>
        <div className="dash-card">
          <h3>Account Settings</h3>
          <p>Password, notifications, and account management.</p>
          <Link href="/settings">Open Settings →</Link>
        </div>
      </div>
    </div>
  );
}
