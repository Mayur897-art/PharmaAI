'use client';

import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/components/AuthProvider';
import { createClient } from '@/lib/supabase/client';

const USER_TYPES = [
  { value: 'student', label: 'Student' },
  { value: 'pharmacy_professional', label: 'Pharmacy Professional' },
  { value: 'healthcare_professional', label: 'Healthcare Professional' },
  { value: 'working_professional', label: 'Working Professional' },
  { value: 'other', label: 'Other' },
];

export default function ProfilePage() {
  const { user, profile, loading, refreshProfile } = useAuth();
  const supabase = createClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [fullName, setFullName] = useState('');
  const [userType, setUserType] = useState('other');
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name || '');
      setUserType(profile.user_type || 'other');
      setBio(profile.bio || '');
      setAvatarUrl(profile.avatar_url);
    }
  }, [profile]);

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    setUploading(true);
    const ext = file.name.split('.').pop();
    const path = `${user.id}/avatar.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(path, file, { upsert: true });

    if (uploadError) {
      setMessage({ type: 'error', text: `Avatar upload failed: ${uploadError.message}` });
      setUploading(false);
      return;
    }

    const { data } = supabase.storage.from('avatars').getPublicUrl(path);
    setAvatarUrl(`${data.publicUrl}?t=${Date.now()}`);
    setUploading(false);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setSaving(true);
    setMessage(null);

    const { error } = await supabase
      .from('profiles')
      .update({
        full_name: fullName,
        user_type: userType,
        bio,
        avatar_url: avatarUrl,
      })
      .eq('auth_user_id', user.id);

    setSaving(false);

    if (error) {
      setMessage({ type: 'error', text: error.message });
      return;
    }

    await refreshProfile();
    setMessage({ type: 'success', text: 'Profile saved.' });
  }

  if (loading) return <div className="centered-msg">Loading…</div>;

  return (
    <div className="wrap app-shell" style={{ maxWidth: 720 }}>
      <div className="app-header">
        <h1>My Profile</h1>
        <p>Keep your account details up to date.</p>
      </div>

      {message && (
        <div className={`alert ${message.type === 'error' ? 'alert-error' : 'alert-success'}`}>
          {message.text}
        </div>
      )}

      <form className="panel" onSubmit={handleSave}>
        <h2>Profile details</h2>

        <div style={{ display: 'flex', alignItems: 'center', gap: 22, marginBottom: 28 }}>
          <div className="avatar-lg">
            {avatarUrl ? <img src={avatarUrl} alt="Avatar" /> : (fullName || user?.email || '?').charAt(0).toUpperCase()}
          </div>
          <div>
            <button
              type="button"
              className="btn btn-dark-outline"
              style={{ color: 'var(--navy)', borderColor: 'var(--navy)' }}
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
            >
              {uploading ? 'Uploading…' : 'Change Photo'}
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              hidden
              onChange={handleAvatarUpload}
            />
          </div>
        </div>

        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" value={user?.email || ''} disabled />
        </div>

        <div className="field">
          <label htmlFor="fullName">Full Name</label>
          <input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} />
        </div>

        <div className="field">
          <label htmlFor="userType">User Type</label>
          <select id="userType" value={userType} onChange={(e) => setUserType(e.target.value)}>
            {USER_TYPES.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>

        <div className="field">
          <label htmlFor="bio">Bio</label>
          <textarea id="bio" rows={4} value={bio} onChange={(e) => setBio(e.target.value)} />
        </div>

        <button type="submit" className="btn btn-solid" disabled={saving}>
          {saving ? 'Saving…' : 'Save Profile'}
        </button>
      </form>
    </div>
  );
}
