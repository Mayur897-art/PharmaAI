'use client';

import { useState, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

function LoginForm() {
  const supabase = createClient();
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectedFrom = searchParams.get('redirectedFrom') || '/dashboard';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);

    if (signInError) {
      const msg = signInError.message.toLowerCase();
      // Note: Supabase deliberately returns the same generic error for both
      // "wrong password" and "no account with this email" — revealing which
      // one it is would let an attacker enumerate registered emails, so we
      // keep this message equally generic rather than splitting it apart.
      if (msg.includes('invalid login credentials')) {
        setError('Incorrect email or password. Please try again.');
      } else if (msg.includes('email not confirmed')) {
        setError('Please verify your email before logging in. Check your inbox for the verification link.');
      } else if (msg.includes('fetch') || msg.includes('network')) {
        setError('Network error. Check your connection and try again.');
      } else {
        setError(signInError.message);
      }
      return;
    }

    router.push(redirectedFrom);
    router.refresh();
  }

  async function handleGoogle() {
    const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin;
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${siteUrl}/auth/callback?next=${redirectedFrom}` },
    });
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Welcome Back to Pharma AI</h1>
        <p className="sub">Sign in to continue your Pharma AI journey.</p>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <div className="password-wrap">
              <input
                id="password"
                type={showPw ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              <button type="button" onClick={() => setShowPw((s) => !s)}>
                {showPw ? 'Hide' : 'Show'}
              </button>
            </div>
          </div>

          <div className="forgot-link">
            <Link href="/forgot-password">Forgot Password?</Link>
          </div>

          <button type="submit" className="btn btn-solid btn-block" disabled={loading}>
            {loading ? 'Signing in…' : 'Login'}
          </button>
        </form>

        <div className="divider">OR</div>

        <button className="google-btn" onClick={handleGoogle} type="button">
          Continue with Google
        </button>

        <p className="auth-foot">
          Don&apos;t have an account? <Link href="/signup">Create Account</Link>
        </p>
      </div>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="centered-msg">Loading…</div>}>
      <LoginForm />
    </Suspense>
  );
}
