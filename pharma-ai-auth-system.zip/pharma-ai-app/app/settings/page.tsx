'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/components/AuthProvider';
import { createClient } from '@/lib/supabase/client';

export default function SettingsPage() {
  const { user, loading } = useAuth();
  const supabase = createClient();
  const router = useRouter();

  const [tab, setTab] = useState<'account' | 'security' | 'danger'>('account');

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwMessage, setPwMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [pwSaving, setPwSaving] = useState(false);

  const [confirmDeleteText, setConfirmDeleteText] = useState('');
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  async function handlePasswordChange(e: React.FormEvent) {
    e.preventDefault();
    setPwMessage(null);

    if (newPassword.length < 8) {
      setPwMessage({ type: 'error', text: 'Password must be at least 8 characters.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwMessage({ type: 'error', text: 'Passwords do not match.' });
      return;
    }

    setPwSaving(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setPwSaving(false);

    if (error) {
      setPwMessage({ type: 'error', text: error.message });
      return;
    }
    setNewPassword('');
    setConfirmPassword('');
    setPwMessage({ type: 'success', text: 'Password updated.' });
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/');
    router.refresh();
  }

  async function handleDeleteAccount() {
    if (confirmDeleteText !== 'DELETE') return;
    setDeleting(true);
    setDeleteError(null);

    const {
      data: { session },
    } = await supabase.auth.getSession();

    const res = await fetch('/api/delete-account', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session?.access_token}`,
      },
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      setDeleteError(body.error || 'Could not delete your account. Please try again.');
      setDeleting(false);
      return;
    }

    await supabase.auth.signOut();
    router.push('/');
  }

  if (loading) return <div className="centered-msg">Loading…</div>;

  return (
    <div className="wrap app-shell" style={{ maxWidth: 720 }}>
      <div className="app-header">
        <h1>Account Settings</h1>
        <p>Manage your account information, security, and password.</p>
      </div>

      <div className="settings-tabs">
        <button className={tab === 'account' ? 'active' : ''} onClick={() => setTab('account')}>
          Account Information
        </button>
        <button className={tab === 'security' ? 'active' : ''} onClick={() => setTab('security')}>
          Security &amp; Password
        </button>
        <button className={tab === 'danger' ? 'active' : ''} onClick={() => setTab('danger')}>
          Danger Zone
        </button>
      </div>

      {tab === 'account' && (
        <div className="panel">
          <h2>Account Information</h2>
          <div className="field">
            <label>Email</label>
            <input value={user?.email || ''} disabled />
          </div>
          <div className="field">
            <label>Account created</label>
            <input value={user?.created_at ? new Date(user.created_at).toLocaleDateString() : ''} disabled />
          </div>
          <button className="btn btn-dark-outline" style={{ color: 'var(--navy)', borderColor: 'var(--navy)' }} onClick={handleLogout}>
            Logout
          </button>
        </div>
      )}

      {tab === 'security' && (
        <div className="panel">
          <h2>Change Password</h2>
          {pwMessage && (
            <div className={`alert ${pwMessage.type === 'error' ? 'alert-error' : 'alert-success'}`}>
              {pwMessage.text}
            </div>
          )}
          <form onSubmit={handlePasswordChange}>
            <div className="field">
              <label htmlFor="newPassword">New Password</label>
              <input
                id="newPassword"
                type="password"
                minLength={8}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label htmlFor="confirmPassword">Confirm New Password</label>
              <input
                id="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            <button type="submit" className="btn btn-solid" disabled={pwSaving}>
              {pwSaving ? 'Updating…' : 'Update Password'}
            </button>
          </form>
        </div>
      )}

      {tab === 'danger' && (
        <div className="danger-zone">
          <h3>Delete Account</h3>
          <p style={{ marginBottom: 16, color: 'var(--ink)' }}>
            This permanently deletes your account and profile. This cannot be undone.
          </p>
          {deleteError && <div className="alert alert-error">{deleteError}</div>}
          <div className="field">
            <label htmlFor="confirmDelete">Type DELETE to confirm</label>
            <input
              id="confirmDelete"
              value={confirmDeleteText}
              onChange={(e) => setConfirmDeleteText(e.target.value)}
            />
          </div>
          <button
            className="btn btn-danger"
            disabled={confirmDeleteText !== 'DELETE' || deleting}
            onClick={handleDeleteAccount}
          >
            {deleting ? 'Deleting…' : 'Permanently Delete My Account'}
          </button>
        </div>
      )}
    </div>
  );
}
