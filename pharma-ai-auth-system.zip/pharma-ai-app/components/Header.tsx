'use client';

import Link from 'next/link';
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from './AuthProvider';
import { createClient } from '@/lib/supabase/client';

export default function Header() {
  const { user, profile, loading } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const supabase = createClient();

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    setMenuOpen(false);
    router.push('/');
    router.refresh();
  }

  const initials = (profile?.full_name || user?.email || '?').trim().charAt(0).toUpperCase();

  return (
    <header className="site-header">
      <div className="wrap nav">
        <Link href="/" className="logo">
          PHARMA<span className="ai">AI</span>
        </Link>

        <nav className="nav-links">
          <Link href="/#pv">Pharmacovigilance</Link>
          <Link href="/#analytics">Analytics</Link>
          <Link href="/#ai">AI in Pharma</Link>
          <Link href="/#career">Career Hub</Link>
        </nav>

        {loading ? (
          <div className="auth-slot" />
        ) : user ? (
          <div className="auth-slot" ref={menuRef}>
            <Link href="/dashboard" className="btn btn-dark-outline">
              Dashboard
            </Link>
            <button
              className="avatar-btn"
              onClick={() => setMenuOpen((o) => !o)}
              aria-haspopup="true"
              aria-expanded={menuOpen}
              aria-label="Account menu"
            >
              {initials}
            </button>
            {menuOpen && (
              <div className="avatar-menu">
                <Link href="/dashboard" onClick={() => setMenuOpen(false)}>
                  Dashboard
                </Link>
                <Link href="/profile" onClick={() => setMenuOpen(false)}>
                  Profile
                </Link>
                <Link href="/settings" onClick={() => setMenuOpen(false)}>
                  Settings
                </Link>
                <button onClick={handleLogout}>Logout</button>
              </div>
            )}
          </div>
        ) : (
          <div className="auth-slot">
            <Link href="/login" className="btn btn-dark-outline">
              Login
            </Link>
            <Link href="/signup" className="btn btn-solid">
              Create Account
            </Link>
          </div>
        )}
      </div>
    </header>
  );
}
