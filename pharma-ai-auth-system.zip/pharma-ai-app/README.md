# Pharma AI — Authentication System

Real authentication for Pharma AI, built on **Next.js 14 (App Router)** +
**Supabase Auth** + **Supabase Postgres**, keeping the existing navy/emerald
brand. No fake/demo login anywhere — every screen below talks to a real
Supabase project.

---

## What's inside

```
app/
  page.tsx                     Homepage (existing sections, kept)
  login/page.tsx               /login
  signup/page.tsx              /signup
  forgot-password/page.tsx     /forgot-password
  reset-password/page.tsx      /reset-password
  auth/callback/route.ts       OAuth + email-verification callback
  dashboard/page.tsx           /dashboard        (protected)
  profile/page.tsx             /profile          (protected)
  settings/page.tsx            /settings         (protected)
  api/delete-account/route.ts  Server-only account deletion
components/
  AuthProvider.tsx             Global auth state (user, profile, loading)
  Header.tsx                   Auth-aware nav (Login/Signup vs Dashboard/Avatar)
lib/supabase/
  client.ts                    Browser Supabase client
  server.ts                    Server Supabase client + admin (service role) client
middleware.ts                  Session refresh + route protection
supabase/schema.sql            Table, RLS policies, triggers, storage bucket
```

A quick correction to one part of the original spec, so the security model
is accurate: Supabase intentionally returns the *same* error for "wrong
password" and "no account with that email," and the password-reset and
signup flows always show the same success message regardless of whether the
email is registered. This is standard practice — revealing which case
occurred lets an attacker enumerate real user emails. The login screen still
shows a clear message ("Incorrect email or password"), it just doesn't
distinguish which of the two it was.

---

## 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**.
2. Pick an org, name it `pharma-ai`, set a database password (save it), pick a region.
3. Wait for provisioning (~2 min).

## 2. Create the database schema

1. In Supabase Studio, open **SQL Editor → New query**.
2. Paste the entire contents of `supabase/schema.sql` and run it.
3. Confirm under **Table Editor** that a `profiles` table now exists, and
   under **Storage** that an `avatars` bucket exists.

This one file creates: the `profiles` table, RLS policies (select/update/insert
restricted to `auth.uid() = auth_user_id`, no delete policy, no "allow all"
policy anywhere), the trigger that auto-creates a profile row the moment a
user signs up by *any* method, and the `avatars` storage bucket with
owner-only write access.

## 3. Enable email authentication

1. **Authentication → Providers → Email** → make sure it's enabled.
2. **Authentication → Settings → Confirm email** → turn this **on** (required
   for the "Email Verification" requirement).
3. **Authentication → Emails**: optionally customize the confirmation and
   password-reset templates to match Pharma AI branding.

## 4. Enable Google OAuth

1. In [Google Cloud Console](https://console.cloud.google.com/apis/credentials),
   create an **OAuth 2.0 Client ID** (type: Web application).
2. Authorized redirect URI — use the one Supabase gives you, of the form:
   `https://YOUR-PROJECT-REF.supabase.co/auth/v1/callback`
3. Copy the generated **Client ID** and **Client Secret**.
4. In Supabase: **Authentication → Providers → Google** → paste both, save.

## 5. Add redirect URLs (both local and production)

**Authentication → URL Configuration**:
- **Site URL**: `http://localhost:3000` while developing, your real domain
  (e.g. `https://pharmaai.com`) in production.
- **Redirect URLs**, add both:
  - `http://localhost:3000/auth/callback`
  - `https://YOUR-PRODUCTION-DOMAIN/auth/callback`

Without this step, Google login and email verification links will fail to
redirect back into the app.

## 6. Get your API keys

**Project Settings → API**:
- `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
- `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
- `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` — **server-only, never
  commit this, never prefix it with `NEXT_PUBLIC_`.**

## 7. Set environment variables

```bash
cp .env.local.example .env.local
```

Fill in the four values from steps above. `.env.local` is already git-ignored.

## 8. Run it locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

### Test the full flow
1. **Sign up** at `/signup` with a real email → check inbox for the
   verification email.
2. Click the link → lands on `/auth/callback` → redirected to `/dashboard`.
3. **Log out**, then **log in** at `/login` with the same credentials.
4. Visit `/profile`, edit your name/bio/avatar, **Save Profile**.
5. Visit `/settings` → **Change Password** → log out → log back in with the
   new password.
6. Try `/forgot-password` with that email → click the emailed link → lands
   on `/reset-password` → set a new password → redirected to `/login`.
7. Try **Continue with Google** on `/signup` or `/login` → should create/sign
   in the user and land on `/dashboard`.
8. Log out, then try opening `/dashboard` directly → you should be bounced
   to `/login?redirectedFrom=/dashboard`, and after logging in you should
   land back on `/dashboard`, not the homepage.
9. On `/settings` → Danger Zone, type `DELETE`, delete the account, confirm
   you're signed out and the row disappeared from the `profiles` table.

## 9. Deploy

**Vercel** (simplest path for Next.js):
1. Push this project to a GitHub repo.
2. [vercel.com/new](https://vercel.com/new) → import the repo.
3. Add the same four environment variables from `.env.local` in the Vercel
   project settings (Production + Preview).
4. Deploy.
5. Go back to Supabase **URL Configuration** and add
   `https://your-vercel-domain.vercel.app/auth/callback` (and your real
   custom domain once attached) to the Redirect URLs list, and update the
   Google Cloud OAuth client's authorized redirect URI if you use a custom
   domain.

---

## Notes on what's deliberately *not* done yet

- **Payments**: `profiles.subscription_status` (`free`/`premium`) and
  `subscription_plan` exist so premium resources can be gated later, but no
  Stripe/Razorpay integration is wired up, per the brief.
- **"My Resources" / "My Courses" / "Recently Viewed"**: the dashboard shows
  these sections and stat placeholders, but they read from tables that
  don't exist yet — add a `resources`, `courses`, and `activity` table with
  the same RLS pattern as `profiles` when you're ready to make them real.
- **Email change**: the profile page shows email as read-only, matching the
  brief; wiring up Supabase's secure email-change verification is a small
  follow-up (`supabase.auth.updateUser({ email })` plus confirming via the
  emailed link) if you want users to change it themselves.
