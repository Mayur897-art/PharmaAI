import { createBrowserClient } from '@supabase/ssr';

/**
 * Supabase client for use inside 'use client' components.
 * Reads the two PUBLIC env vars only — never the service role key.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
