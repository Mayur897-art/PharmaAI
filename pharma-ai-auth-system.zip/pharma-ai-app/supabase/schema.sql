-- ============================================================
-- Pharma AI — Supabase schema
-- Run this whole file once in Supabase Studio → SQL Editor.
-- ============================================================

create extension if not exists "uuid-ossp";

-- ------------------------------------------------------------
-- 1. profiles table
--    One row per auth.users row. Never stores passwords —
--    Supabase Auth owns credentials entirely.
-- ------------------------------------------------------------
create table if not exists public.profiles (
  id                   uuid primary key default uuid_generate_v4(),
  auth_user_id         uuid not null unique references auth.users(id) on delete cascade,
  full_name            text,
  email                text,
  user_type            text default 'other'
                         check (user_type in ('student','pharmacy_professional','healthcare_professional','working_professional','other')),
  avatar_url           text,
  bio                  text,
  subscription_status  text not null default 'free' check (subscription_status in ('free','premium')),
  subscription_plan    text,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);

create index if not exists profiles_auth_user_id_idx on public.profiles (auth_user_id);

-- ------------------------------------------------------------
-- 2. Row Level Security — deny by default, then allow narrowly.
--    No "allow all" policy exists anywhere in this file.
-- ------------------------------------------------------------
alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own"
  on public.profiles for select
  using (auth.uid() = auth_user_id);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
  on public.profiles for update
  using (auth.uid() = auth_user_id)
  with check (auth.uid() = auth_user_id);

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own"
  on public.profiles for insert
  with check (auth.uid() = auth_user_id);

-- No delete policy for regular users: account deletion goes through the
-- server-side /api/delete-account route using the service role key, which
-- deletes the auth.users row and cascades to profiles automatically.

-- ------------------------------------------------------------
-- 3. Auto-create a profile row whenever a new auth user appears —
--    covers BOTH email/password signup and Google OAuth signup,
--    so the client never has to remember to do this itself.
-- ------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (auth_user_id, email, full_name, user_type)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''),
    coalesce(new.raw_user_meta_data->>'user_type', 'other')
  )
  on conflict (auth_user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ------------------------------------------------------------
-- 4. Keep updated_at current on every profile edit
-- ------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at
  before update on public.profiles
  for each row execute function public.set_updated_at();

-- ------------------------------------------------------------
-- 5. Storage bucket for avatar uploads (public read, owner-only write)
-- ------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('avatars', 'avatars', true)
on conflict (id) do nothing;

drop policy if exists "avatar_public_read" on storage.objects;
create policy "avatar_public_read"
  on storage.objects for select
  using (bucket_id = 'avatars');

drop policy if exists "avatar_owner_write" on storage.objects;
create policy "avatar_owner_write"
  on storage.objects for insert
  with check (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);

drop policy if exists "avatar_owner_update" on storage.objects;
create policy "avatar_owner_update"
  on storage.objects for update
  using (bucket_id = 'avatars' and auth.uid()::text = (storage.foldername(name))[1]);
